"""
Telegram Business Alerts Bot
Handles commands, scheduled alerts, and threshold monitoring.
"""

import asyncio
import io
import logging
import os
import threading
import time
from datetime import datetime

import schedule
from dotenv import load_dotenv
from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import Application, CommandHandler, ContextTypes

from data import (
    generate_sample_report_csv,
    get_active_alerts,
    get_current_metrics,
    get_sales_breakdown,
    get_weekly_summary,
)
from formatters import (
    format_alert_message,
    format_help_message,
    format_scheduled_daily_alert,
    format_status_message,
    format_threshold_alert,
    format_weekly_report,
)

load_dotenv()

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
REVENUE_THRESHOLD = float(os.getenv("REVENUE_THRESHOLD", "10000"))
ERROR_RATE_THRESHOLD = float(os.getenv("ERROR_RATE_THRESHOLD", "5.0"))
RESPONSE_TIME_THRESHOLD = float(os.getenv("RESPONSE_TIME_THRESHOLD", "2000"))
DAILY_REPORT_TIME = os.getenv("DAILY_REPORT_TIME", "09:00")

# Global reference to the running Application for scheduled jobs
_app: Application | None = None


# ─── Command Handlers ────────────────────────────────────────────────────────

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "👋 *Business Alerts Bot is online\\!*\n\n"
        "I monitor your business metrics and send real\\-time alerts\\.\n\n"
        "Type /help to see available commands\\.",
        parse_mode=ParseMode.MARKDOWN_V2,
    )


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        format_help_message(),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action("typing")
    metrics = get_current_metrics()
    await update.message.reply_text(
        format_status_message(metrics),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


async def cmd_report(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action("typing")
    summary = get_weekly_summary()
    breakdown = get_sales_breakdown()
    await update.message.reply_text(
        format_weekly_report(summary, breakdown),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


async def cmd_report_csv(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action("upload_document")
    csv_content = generate_sample_report_csv()
    filename = f"weekly_report_{datetime.now().strftime('%Y%m%d')}.csv"
    csv_bytes = io.BytesIO(csv_content.encode("utf-8"))
    csv_bytes.name = filename
    await update.message.reply_document(
        document=csv_bytes,
        filename=filename,
        caption=f"📎 Weekly report — {datetime.now().strftime('%b %d, %Y')}",
    )


async def cmd_alerts(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action("typing")
    active = get_active_alerts()

    if not active:
        await update.message.reply_text(
            "✅ *No active alerts*\n\n_All systems are operating normally\\._",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return

    await update.message.reply_text(
        f"🔔 *{len(active)} Active Alert{'s' if len(active) > 1 else ''}*",
        parse_mode=ParseMode.MARKDOWN_V2,
    )
    for alert in active:
        await update.message.reply_text(
            format_alert_message(alert),
            parse_mode=ParseMode.MARKDOWN_V2,
        )


# ─── Scheduled Jobs ──────────────────────────────────────────────────────────

async def _send_to_chat(text: str, parse_mode: str = ParseMode.MARKDOWN_V2) -> None:
    """Send a message to the configured chat ID."""
    if _app is None or not CHAT_ID:
        logger.warning("Cannot send scheduled message: app or CHAT_ID not set")
        return
    try:
        await _app.bot.send_message(
            chat_id=CHAT_ID,
            text=text,
            parse_mode=parse_mode,
        )
    except Exception as e:
        logger.error("Failed to send scheduled message: %s", e)


def run_daily_briefing() -> None:
    """Triggered by schedule: sends the daily morning briefing."""
    metrics = get_current_metrics()
    asyncio.run_coroutine_threadsafe(
        _send_to_chat(format_scheduled_daily_alert(metrics)),
        _app.loop,  # type: ignore[union-attr]
    )
    logger.info("Daily briefing sent")


def run_threshold_check() -> None:
    """Triggered by schedule: checks metrics and fires threshold alerts."""
    metrics = get_current_metrics()

    if metrics["revenue_today"] < REVENUE_THRESHOLD:
        asyncio.run_coroutine_threadsafe(
            _send_to_chat(
                format_threshold_alert(
                    "Daily Revenue",
                    metrics["revenue_today"],
                    REVENUE_THRESHOLD,
                    " USD",
                )
            ),
            _app.loop,  # type: ignore[union-attr]
        )
        logger.info("Revenue threshold alert fired: %.2f", metrics["revenue_today"])

    if metrics["error_rate"] > ERROR_RATE_THRESHOLD:
        asyncio.run_coroutine_threadsafe(
            _send_to_chat(
                format_threshold_alert(
                    "API Error Rate",
                    metrics["error_rate"],
                    ERROR_RATE_THRESHOLD,
                    "%",
                )
            ),
            _app.loop,  # type: ignore[union-attr]
        )
        logger.info("Error rate threshold alert fired: %.2f%%", metrics["error_rate"])

    if metrics["avg_response_ms"] > RESPONSE_TIME_THRESHOLD:
        asyncio.run_coroutine_threadsafe(
            _send_to_chat(
                format_threshold_alert(
                    "Avg Response Time",
                    metrics["avg_response_ms"],
                    RESPONSE_TIME_THRESHOLD,
                    " ms",
                )
            ),
            _app.loop,  # type: ignore[union-attr]
        )
        logger.info("Response time threshold alert fired: %d ms", metrics["avg_response_ms"])


def _start_scheduler() -> None:
    """Run the schedule loop in a background thread."""
    schedule.every().day.at(DAILY_REPORT_TIME).do(run_daily_briefing)
    schedule.every(30).minutes.do(run_threshold_check)

    logger.info("Scheduler started — daily briefing at %s, threshold checks every 30min", DAILY_REPORT_TIME)

    while True:
        schedule.run_pending()
        time.sleep(30)


# ─── Entry Point ─────────────────────────────────────────────────────────────

def main() -> None:
    if not BOT_TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN is not set in .env")
    if not CHAT_ID:
        logger.warning("TELEGRAM_CHAT_ID not set — scheduled alerts will not be delivered")

    global _app
    _app = (
        Application.builder()
        .token(BOT_TOKEN)
        .build()
    )

    _app.add_handler(CommandHandler("start", cmd_start))
    _app.add_handler(CommandHandler("help", cmd_help))
    _app.add_handler(CommandHandler("status", cmd_status))
    _app.add_handler(CommandHandler("report", cmd_report))
    _app.add_handler(CommandHandler("report_csv", cmd_report_csv))
    _app.add_handler(CommandHandler("alerts", cmd_alerts))

    # Start scheduler in a daemon thread
    scheduler_thread = threading.Thread(target=_start_scheduler, daemon=True)
    scheduler_thread.start()

    logger.info("Bot started — polling for updates")
    _app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
