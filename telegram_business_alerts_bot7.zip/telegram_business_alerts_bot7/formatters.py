"""
Markdown message formatters for all alert types.
All output uses Telegram MarkdownV2 formatting.
"""

from datetime import datetime
from data import get_current_metrics, get_weekly_summary, get_active_alerts, get_sales_breakdown


def _escape(text: str) -> str:
    """Escape special characters for Telegram MarkdownV2."""
    special = r"_*[]()~`>#+-=|{}.!"
    return "".join(f"\\{c}" if c in special else c for c in str(text))


def format_status_message(metrics: dict) -> str:
    """Format the /status command response."""
    rev = metrics["revenue_today"]
    err = metrics["error_rate"]
    rt = metrics["avg_response_ms"]

    rev_icon = "🟢" if rev >= 10000 else "🟡" if rev >= 7000 else "🔴"
    err_icon = "🟢" if err < 2 else "🟡" if err < 5 else "🔴"
    rt_icon = "🟢" if rt < 1000 else "🟡" if rt < 2000 else "🔴"

    lines = [
        "📊 *Business Status \\— Live*",
        f"_{_escape(datetime.now().strftime('%b %d, %Y %H:%M'))}_",
        "",
        "💰 *Revenue*",
        f"  {rev_icon} Today: `${_escape(f'{rev:,.2f}')}`",
        f"  📦 Orders: `{metrics['orders_today']}`",
        f"  🔄 Conversion: `{_escape(metrics['conversion_rate'])}%`",
        "",
        "👥 *Users*",
        f"  🟢 Active: `{metrics['active_users']}`",
        f"  ✨ New signups: `{metrics['new_signups']}`",
        f"  🛒 Cart abandonments: `{metrics['cart_abandonments']}`",
        "",
        "⚙️ *System Health*",
        f"  {err_icon} Error rate: `{_escape(metrics['error_rate'])}%`",
        f"  {rt_icon} Avg response: `{metrics['avg_response_ms']} ms`",
        "",
        "Use /report for a full weekly summary\\.",
    ]
    return "\n".join(lines)


def format_weekly_report(summary: dict, breakdown: dict) -> str:
    """Format the /report command response."""
    def _day_line(d: dict) -> str:
        rev_str = _escape(f"{d['revenue']:,.0f}")
        return f"  `{d['date']}` — `${rev_str}` \\| `{d['orders']} orders`"

    days_table = "\n".join(_day_line(d) for d in summary["days"])

    channels = breakdown["channels"]
    ch_lines = "\n".join(
        f"  • {_escape(k.replace('_', ' ').title())}: `{v}%`"
        for k, v in sorted(channels.items(), key=lambda x: -x[1])
    )

    countries = "\n".join(
        f"  • {flag}: `{pct}%`"
        for flag, pct in breakdown["top_countries"]
    )

    lines = [
        "📈 *Weekly Business Report*",
        f"_Week ending {_escape(datetime.now().strftime('%b %d, %Y'))}_",
        "",
        "📅 *Daily Breakdown*",
        days_table,
        "",
        "💼 *Summary*",
        f"  💵 Total revenue: `${_escape('{:,.2f}'.format(summary['total_revenue']))}`",
        f"  📦 Total orders: `{summary['total_orders']}`",
        f"  📊 Avg daily revenue: `${_escape('{:,.2f}'.format(summary['avg_daily_revenue']))}`",
        f"  🏆 Best day: `{_escape(summary['best_day'])}`",
        f"  ⭐ Top product: `{_escape(summary['top_product'])}`",
        f"  📉 Churn rate: `{_escape(summary['churn_rate'])}%`",
        f"  😊 NPS score: `{summary['nps_score']}`",
        "",
        "📡 *Traffic by Channel*",
        ch_lines,
        "",
        "🌍 *Top Countries*",
        countries,
        "",
        "📎 Attach /report\\_csv to get full data as CSV file\\.",
    ]
    return "\n".join(lines)


def format_alert_message(alert: dict) -> str:
    """Format a single alert notification."""
    icons = {"critical": "🚨", "warning": "⚠️", "info": "ℹ️"}
    icon = icons.get(alert["level"], "🔔")
    level_label = alert["level"].upper()

    lines = [
        f"{icon} *ALERT \\— {_escape(level_label)}*",
        "",
        f"📌 *Type:* {_escape(alert['type'].replace('_', ' ').title())}",
        f"💬 *Message:* {_escape(alert['message'])}",
        f"🕐 *Since:* {_escape(alert['since'])}",
        f"🎯 *Affected:* {_escape(alert['affected'])}",
        "",
        f"_Detected at {_escape(datetime.now().strftime('%H:%M:%S'))}_",
    ]
    return "\n".join(lines)


def format_scheduled_daily_alert(metrics: dict) -> str:
    """Format the scheduled daily morning alert."""
    rev = metrics["revenue_today"]
    trend = "📈" if rev >= 10000 else "📉"

    lines = [
        f"☀️ *Good Morning\\! Daily Business Briefing*",
        f"_{_escape(datetime.now().strftime('%A, %B %d %Y'))}_",
        "",
        f"  {trend} Yesterday's revenue: `${_escape(f'{rev:,.2f}')}`",
        f"  📦 Orders processed: `{metrics['orders_today']}`",
        f"  👥 Active users: `{metrics['active_users']}`",
        f"  🔄 Conversion rate: `{_escape(metrics['conversion_rate'])}%`",
        "",
        "Type /status for live metrics or /report for full weekly summary\\.",
    ]
    return "\n".join(lines)


def format_threshold_alert(metric_name: str, value: float, threshold: float, unit: str = "") -> str:
    """Format a threshold breach alert."""
    lines = [
        "🚨 *Threshold Alert*",
        "",
        f"📊 *Metric:* `{_escape(metric_name)}`",
        f"📈 *Current value:* `{_escape(f'{value:.2f}')}{_escape(unit)}`",
        f"⚠️ *Threshold:* `{_escape(f'{threshold:.2f}')}{_escape(unit)}`",
        f"🕐 *Time:* `{_escape(datetime.now().strftime('%H:%M:%S'))}`",
        "",
        "_Automatic alert triggered by monitoring system\\._",
    ]
    return "\n".join(lines)


def format_help_message() -> str:
    """Format the /help command response."""
    lines = [
        "🤖 *Business Alerts Bot — Help*",
        "",
        "📋 *Available Commands*",
        "",
        "/status — Live business metrics dashboard",
        "/report — Full weekly performance report",
        "/report\\_csv — Download weekly data as CSV file",
        "/alerts — Show currently active alerts",
        "/help — Show this help message",
        "",
        "🔔 *Automatic Alerts*",
        "The bot sends automatic notifications for:",
        "• Daily morning briefing",
        "• Revenue below threshold",
        "• Error rate above threshold",
        "• Response time spikes",
        "• Critical system events",
        "",
        "⚙️ *Configuration*",
        "All thresholds are set in the \\.env file\\.",
        "Contact your admin to adjust alert settings\\.",
    ]
    return "\n".join(lines)
