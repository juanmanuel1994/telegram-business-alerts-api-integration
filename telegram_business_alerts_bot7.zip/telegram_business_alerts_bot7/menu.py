# -*- coding: utf-8 -*-
"""
Telegram Business Alerts Bot — Launcher Menu
"""

import os
import subprocess
import sys
import time
import threading
from pathlib import Path

# Force UTF-8 output on Windows so emojis and box-drawing render correctly
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")

from rich.align import Align
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.prompt import Prompt
from rich.rule import Rule
from rich.table import Table
from rich.text import Text
from rich import box

console = Console(force_terminal=True, highlight=False)

HERE = Path(__file__).parent

# ── Palette ──────────────────────────────────────────────────────────────────
C_TITLE   = "bold cyan"
C_ACCENT  = "bright_cyan"
C_GREEN   = "bright_green"
C_YELLOW  = "bright_yellow"
C_RED     = "bright_red"
C_MUTED   = "grey58"
C_WHITE   = "bold white"
C_BLUE    = "bright_blue"
C_MAGENTA = "bright_magenta"

# ── Menu items ────────────────────────────────────────────────────────────────
MENU_ITEMS = [
    {
        "key": "1",
        "label": "Launch Telegram Bot",
        "desc": "Start the bot — polls Telegram & processes commands",
        "icon": "🤖",
        "script": "bot.py",
        "color": C_GREEN,
    },
    {
        "key": "2",
        "label": "Preview Live Metrics",
        "desc": "Simulate /status output in the terminal",
        "icon": "📊",
        "script": None,
        "action": "preview_metrics",
        "color": C_ACCENT,
    },
    {
        "key": "3",
        "label": "Preview Weekly Report",
        "desc": "Simulate /report output in the terminal",
        "icon": "📈",
        "script": None,
        "action": "preview_report",
        "color": C_BLUE,
    },
    {
        "key": "4",
        "label": "Preview Active Alerts",
        "desc": "Simulate /alerts output in the terminal",
        "icon": "🔔",
        "script": None,
        "action": "preview_alerts",
        "color": C_YELLOW,
    },
    {
        "key": "5",
        "label": "Generate CSV Report",
        "desc": "Export weekly data to weekly_report.csv",
        "icon": "📎",
        "script": None,
        "action": "export_csv",
        "color": C_MAGENTA,
    },
    {
        "key": "6",
        "label": "Check .env Configuration",
        "desc": "Verify bot token and settings",
        "icon": "⚙️",
        "script": None,
        "action": "check_env",
        "color": C_WHITE,
    },
    {
        "key": "7",
        "label": "Full Demo Mode",
        "desc": "Simulate a live Telegram chat — no token needed",
        "icon": "💬",
        "script": None,
        "action": "full_demo",
        "color": "bright_green",
    },
    {
        "key": "0",
        "label": "Exit",
        "desc": "Close the launcher",
        "icon": "🚪",
        "script": None,
        "action": "exit",
        "color": C_RED,
    },
]

# ── Animations ────────────────────────────────────────────────────────────────

def animate_banner():
    """Animated banner on startup."""
    lines = [
        " ████████╗███████╗██╗     ███████╗ ██████╗ ██████╗  █████╗ ███╗   ███╗",
        "    ██╔══╝██╔════╝██║     ██╔════╝██╔════╝ ██╔══██╗██╔══██╗████╗ ████║",
        "    ██║   █████╗  ██║     █████╗  ██║  ███╗██████╔╝███████║██╔████╔██║",
        "    ██║   ██╔══╝  ██║     ██╔══╝  ██║   ██║██╔══██╗██╔══██║██║╚██╔╝██║",
        "    ██║   ███████╗███████╗███████╗╚██████╔╝██║  ██║██║  ██║██║ ╚═╝ ██║",
        "    ╚═╝   ╚══════╝╚══════╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝",
    ]
    subtitle = "         🤖  Business Alerts Bot  •  Launcher v1.0  🤖"

    colors = ["cyan", "bright_cyan", "bright_blue", "cyan", "bright_cyan", "bright_blue"]
    console.clear()
    for i, (line, color) in enumerate(zip(lines, colors)):
        console.print(Align.center(Text(line, style=f"bold {color}")))
        time.sleep(0.07)
    time.sleep(0.1)
    console.print()
    console.print(Align.center(Text(subtitle, style="bold bright_white")))
    console.print()


def loading_bar(label: str, steps: int = 18, delay: float = 0.04):
    """Animated loading bar."""
    with Progress(
        SpinnerColumn(style=C_ACCENT),
        TextColumn(f"[{C_ACCENT}]{label}[/]"),
        BarColumn(bar_width=36, style="cyan", complete_style=C_GREEN),
        TextColumn("[bright_green]{task.percentage:>3.0f}%[/]"),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    ) as prog:
        task = prog.add_task("", total=steps)
        for _ in range(steps):
            time.sleep(delay)
            prog.advance(task)


def spinner_wait(label: str, seconds: float = 1.2):
    """Short spinner for quick operations."""
    with Progress(
        SpinnerColumn(spinner_name="dots2", style=C_ACCENT),
        TextColumn(f"[{C_ACCENT}]{label}[/]"),
        console=console,
        transient=True,
    ) as prog:
        prog.add_task("", total=None)
        time.sleep(seconds)


# ── Menu Rendering ────────────────────────────────────────────────────────────

def render_menu():
    """Draw the main menu table."""
    console.print(Rule(style="cyan dim"))

    table = Table(
        box=box.ROUNDED,
        border_style="cyan",
        header_style=f"bold {C_ACCENT}",
        show_lines=True,
        expand=False,
        min_width=62,
    )
    table.add_column("  #", style="bold white", justify="center", width=4)
    table.add_column("", justify="center", width=4)
    table.add_column("Option", style="bold", width=26)
    table.add_column("Description", style=C_MUTED, width=44)

    for item in MENU_ITEMS:
        table.add_row(
            Text(item["key"], style=f"bold {item['color']}"),
            item["icon"],
            Text(item["label"], style=f"bold {item['color']}"),
            item["desc"],
        )

    console.print(Align.center(table))
    console.print(Rule(style="cyan dim"))
    console.print()


def status_bar():
    """Show a quick status bar: env loaded / script paths."""
    env_ok = (HERE / ".env").exists()
    bot_ok = (HERE / "bot.py").exists()

    row = Table.grid(padding=(0, 2))
    row.add_column()
    row.add_column()
    row.add_column()

    env_txt = Text("● .env loaded", style=C_GREEN if env_ok else C_RED)
    bot_txt = Text("● bot.py found", style=C_GREEN if bot_ok else C_RED)
    dir_txt = Text(f"📁 {HERE.name}", style=C_MUTED)

    row.add_row(env_txt, bot_txt, dir_txt)
    console.print(Align.center(row))
    console.print()


# ── Actions ───────────────────────────────────────────────────────────────────

def run_script(script: str):
    """Launch a Python script as a subprocess."""
    path = HERE / script
    loading_bar(f"Starting {script}", steps=14, delay=0.05)
    console.print()
    console.print(Panel(
        f"[bold green]Launching [cyan]{script}[/cyan] …[/]\n"
        f"[{C_MUTED}]Press Ctrl+C in the terminal to stop the bot.[/]",
        border_style="green",
        box=box.ROUNDED,
    ))
    console.print()
    try:
        subprocess.run([sys.executable, str(path)], check=False)
    except KeyboardInterrupt:
        pass
    console.print()
    console.print(f"[{C_YELLOW}]  ⏎  Returned to launcher.[/]")
    time.sleep(1)


def preview_metrics():
    spinner_wait("Fetching live metrics", 1.0)
    sys.path.insert(0, str(HERE))
    from data import get_current_metrics
    from formatters import format_status_message
    m = get_current_metrics()
    msg = format_status_message(m)

    console.print(Panel(
        msg,
        title="[bold cyan]/status  —  Live Preview[/]",
        border_style="cyan",
        box=box.ROUNDED,
        padding=(1, 2),
    ))


def preview_report():
    spinner_wait("Generating weekly report", 1.4)
    sys.path.insert(0, str(HERE))
    from data import get_weekly_summary, get_sales_breakdown
    from formatters import format_weekly_report
    s = get_weekly_summary()
    b = get_sales_breakdown()
    msg = format_weekly_report(s, b)

    console.print(Panel(
        msg,
        title="[bold bright_blue]/report  —  Weekly Preview[/]",
        border_style="bright_blue",
        box=box.ROUNDED,
        padding=(1, 2),
    ))


def preview_alerts():
    spinner_wait("Checking active alerts", 0.8)
    sys.path.insert(0, str(HERE))
    from data import get_active_alerts
    from formatters import format_alert_message
    alerts = get_active_alerts()

    if not alerts:
        console.print(Panel(
            "[bright_green]✅  No active alerts — all systems nominal.[/]",
            title="[bold bright_yellow]/alerts  —  Preview[/]",
            border_style="bright_yellow",
            box=box.ROUNDED,
            padding=(1, 2),
        ))
    else:
        for a in alerts:
            console.print(Panel(
                format_alert_message(a),
                title=f"[bold bright_yellow]Alert — {a['level'].upper()}[/]",
                border_style="bright_yellow" if a["level"] == "warning" else "bright_red",
                box=box.ROUNDED,
                padding=(1, 2),
            ))


def export_csv():
    spinner_wait("Generating CSV data", 1.0)
    sys.path.insert(0, str(HERE))
    from data import generate_sample_report_csv
    csv_data = generate_sample_report_csv()
    out = HERE / "weekly_report.csv"
    out.write_text(csv_data, encoding="utf-8")

    console.print(Panel(
        f"[bright_green]✅  File saved:[/] [cyan]{out}[/]\n"
        f"[{C_MUTED}]Rows: {len(csv_data.splitlines()) - 1}  •  "
        f"Size: {len(csv_data.encode())} bytes[/]",
        title="[bold bright_magenta]CSV Export Complete[/]",
        border_style="bright_magenta",
        box=box.ROUNDED,
        padding=(1, 2),
    ))


def check_env():
    spinner_wait("Reading configuration", 0.7)
    env_path = HERE / ".env"
    example_path = HERE / ".env.example"

    if not env_path.exists():
        console.print(Panel(
            f"[bright_red]⚠  .env file not found.[/]\n\n"
            f"[{C_MUTED}]Run:[/] [cyan]cp .env.example .env[/]\n"
            f"Then fill in [cyan]TELEGRAM_BOT_TOKEN[/] and [cyan]TELEGRAM_CHAT_ID[/].",
            title="[bold red]Configuration — Missing .env[/]",
            border_style="red",
            box=box.ROUNDED,
            padding=(1, 2),
        ))
        return

    from dotenv import dotenv_values
    cfg = dotenv_values(env_path)

    grid = Table(box=box.SIMPLE, border_style="cyan", show_header=True, expand=False)
    grid.add_column("Variable", style="bold white", width=30)
    grid.add_column("Status", justify="center", width=12)
    grid.add_column("Value preview", style=C_MUTED, width=28)

    checks = [
        "TELEGRAM_BOT_TOKEN",
        "TELEGRAM_CHAT_ID",
        "REVENUE_THRESHOLD",
        "ERROR_RATE_THRESHOLD",
        "RESPONSE_TIME_THRESHOLD",
        "DAILY_REPORT_TIME",
    ]
    for k in checks:
        v = cfg.get(k, "")
        ok = bool(v and v not in ("your_bot_token_here", "your_chat_id_here"))
        status = Text("✓ set", style=C_GREEN) if ok else Text("✗ missing", style=C_RED)
        preview = (v[:6] + "…" if len(v) > 6 and "TOKEN" in k else v) if v else "—"
        grid.add_row(k, status, preview)

    console.print(Panel(
        grid,
        title="[bold cyan]Configuration Check[/]",
        border_style="cyan",
        box=box.ROUNDED,
        padding=(1, 2),
    ))


# ── Full Demo Mode ────────────────────────────────────────────────────────────

def _tg_bubble(sender: str, text: str, is_bot: bool = True, delay: float = 0.018):
    """Render an animated Telegram-style chat bubble."""
    name_style  = "bold bright_cyan"  if is_bot  else "bold bright_yellow"
    border_col  = "cyan"              if is_bot  else "yellow"
    avatar      = "🤖"               if is_bot  else "👤"
    align_fn    = Align.left          if is_bot  else Align.right

    # Build content char-by-char for typing effect
    console.print()
    header = Text(f"{avatar}  {sender}", style=name_style)
    console.print(align_fn(header))

    # Typing indicator
    with Progress(
        SpinnerColumn(spinner_name="dots", style=border_col),
        TextColumn(f"[{border_col}]typing…[/]"),
        console=console,
        transient=True,
    ) as prog:
        prog.add_task("", total=None)
        time.sleep(0.6 + len(text) * 0.001)

    # Print bubble with animated text
    panel = Panel(
        "",
        border_style=border_col,
        box=box.ROUNDED,
        padding=(0, 2),
        width=min(72, console.width - 4),
    )
    displayed = ""
    with Live(align_fn(Panel(displayed, border_style=border_col, box=box.ROUNDED,
                              padding=(0, 2), width=min(72, console.width - 4))),
              console=console, refresh_per_second=30) as live:
        for ch in text:
            displayed += ch
            live.update(align_fn(Panel(
                displayed,
                border_style=border_col,
                box=box.ROUNDED,
                padding=(0, 2),
                width=min(72, console.width - 4),
            )))
            time.sleep(delay)
    console.print()


def _tg_system(msg: str):
    """Grey system/timestamp line."""
    console.print(Align.center(Text(f"── {msg} ──", style="grey42 italic")))
    console.print()


def _tg_user_cmd(cmd: str):
    """Simulate the user sending a command."""
    _tg_bubble("You", cmd, is_bot=False, delay=0.04)
    time.sleep(0.3)


def full_demo():
    """
    Simulate a complete Telegram conversation in the terminal.
    No token, no internet — 100% local fake demo.
    """
    sys.path.insert(0, str(HERE))
    from data import (get_current_metrics, get_weekly_summary,
                      get_sales_breakdown, get_active_alerts)
    from formatters import (format_status_message, format_weekly_report,
                             format_alert_message, format_help_message,
                             format_scheduled_daily_alert, format_threshold_alert)

    console.clear()
    console.print()
    console.print(Align.center(Panel(
        "[bold bright_green]DEMO MODE  —  Simulated Telegram Chat[/]\n"
        "[grey58]No token required. This is exactly how the bot looks in Telegram.[/]",
        border_style="bright_green",
        box=box.DOUBLE,
        padding=(0, 4),
    )))
    console.print()
    time.sleep(0.8)

    # ── Scene 1: bot comes online ──────────────────────────────────────────
    _tg_system("Today  09:00")
    _tg_bubble("BusinessBot", (
        "☀️ Good Morning! Daily Business Briefing\n"
        + format_scheduled_daily_alert(get_current_metrics())
        .replace("\\", "").replace("*", "").replace("`", "")
    ), delay=0.008)
    time.sleep(0.5)

    # ── Scene 2: user sends /help ──────────────────────────────────────────
    _tg_user_cmd("/help")
    _tg_bubble("BusinessBot",
        format_help_message().replace("\\", "").replace("*", "").replace("`", ""),
        delay=0.006)
    time.sleep(0.4)

    # ── Scene 3: user sends /status ───────────────────────────────────────
    _tg_system("09:02")
    _tg_user_cmd("/status")
    m = get_current_metrics()
    _tg_bubble("BusinessBot",
        format_status_message(m).replace("\\", "").replace("*", "").replace("`", ""),
        delay=0.007)
    time.sleep(0.4)

    # ── Scene 4: threshold alert fires automatically ───────────────────────
    _tg_system("09:30  —  Automatic alert")
    _tg_bubble("BusinessBot",
        format_threshold_alert("API Error Rate", 5.8, 5.0, "%")
        .replace("\\", "").replace("*", "").replace("`", ""),
        delay=0.010)
    time.sleep(0.4)

    # ── Scene 5: user sends /alerts ───────────────────────────────────────
    _tg_system("09:31")
    _tg_user_cmd("/alerts")
    alerts = get_active_alerts()
    if not alerts:
        _tg_bubble("BusinessBot", "✅ No active alerts — all systems nominal.")
    else:
        for a in alerts:
            _tg_bubble("BusinessBot",
                format_alert_message(a).replace("\\", "").replace("*", "").replace("`", ""),
                delay=0.008)
    time.sleep(0.4)

    # ── Scene 6: user requests report ─────────────────────────────────────
    _tg_system("11:15")
    _tg_user_cmd("/report")
    s = get_weekly_summary()
    b = get_sales_breakdown()
    _tg_bubble("BusinessBot",
        format_weekly_report(s, b).replace("\\", "").replace("*", "").replace("`", ""),
        delay=0.005)
    time.sleep(0.4)

    # ── Scene 7: user requests CSV ────────────────────────────────────────
    _tg_system("11:16")
    _tg_user_cmd("/report_csv")

    with Progress(
        SpinnerColumn(style="bright_cyan"),
        TextColumn("[bright_cyan]Bot is uploading file…[/]"),
        console=console,
        transient=True,
    ) as prog:
        prog.add_task("", total=None)
        time.sleep(1.2)

    console.print(Align.left(Panel(
        "[bright_cyan]🤖  BusinessBot[/]\n\n"
        "[bright_white]📎  weekly_report_20260611.csv[/]\n"
        "[grey58]7 rows  •  412 bytes[/]",
        border_style="cyan",
        box=box.ROUNDED,
        padding=(0, 2),
        width=44,
    )))
    console.print()
    time.sleep(0.5)

    # ── End card ──────────────────────────────────────────────────────────
    console.print()
    console.print(Align.center(Panel(
        "[bold bright_green]✅  Demo complete![/]\n\n"
        "[white]That is exactly how the bot behaves in a real Telegram chat.\n"
        "Set your [cyan]TELEGRAM_BOT_TOKEN[/] and [cyan]TELEGRAM_CHAT_ID[/]\n"
        "in [cyan].env[/] and run option [bold]1[/] to go live.[/]",
        border_style="bright_green",
        box=box.ROUNDED,
        padding=(1, 4),
    )))
    console.print()


# ── Main loop ─────────────────────────────────────────────────────────────────

def main():
    animate_banner()
    loading_bar("Initialising launcher", steps=20, delay=0.03)
    console.print()

    while True:
        console.clear()
        animate_banner()
        status_bar()
        render_menu()

        choice = Prompt.ask(
            f"  [bold cyan]Select an option[/]",
            console=console,
        ).strip()

        console.print()

        action_map = {item["key"]: item for item in MENU_ITEMS}
        item = action_map.get(choice)

        if item is None:
            console.print(f"  [{C_RED}]✗  Invalid option — please try again.[/]")
            time.sleep(1.2)
            continue

        if item.get("script"):
            run_script(item["script"])

        elif item.get("action") == "preview_metrics":
            preview_metrics()

        elif item.get("action") == "preview_report":
            preview_report()

        elif item.get("action") == "preview_alerts":
            preview_alerts()

        elif item.get("action") == "full_demo":
            full_demo()

        elif item.get("action") == "export_csv":
            export_csv()

        elif item.get("action") == "check_env":
            check_env()

        elif item.get("action") == "exit":
            console.print()
            console.print(Align.center(
                Panel(
                    "[bold cyan]Thanks for using Business Alerts Bot[/] 🤖\n"
                    f"[{C_MUTED}]Goodbye![/]",
                    border_style="cyan",
                    box=box.ROUNDED,
                    padding=(1, 4),
                )
            ))
            console.print()
            time.sleep(0.8)
            sys.exit(0)

        # Pause before returning to menu
        console.print()
        Prompt.ask(f"  [{C_MUTED}]Press Enter to return to menu[/]", console=console, default="")


if __name__ == "__main__":
    main()
