"""
Simulated business data for demo alerts.
In production, replace these functions with real data sources
(database queries, API calls, monitoring systems, etc.).
"""

import random
from datetime import datetime, timedelta


def get_current_metrics() -> dict:
    """Return simulated real-time business metrics."""
    return {
        "revenue_today": round(random.uniform(8000, 15000), 2),
        "orders_today": random.randint(45, 120),
        "active_users": random.randint(200, 800),
        "error_rate": round(random.uniform(0.5, 6.0), 2),
        "avg_response_ms": random.randint(150, 2500),
        "conversion_rate": round(random.uniform(2.0, 8.5), 2),
        "cart_abandonments": random.randint(10, 50),
        "new_signups": random.randint(5, 30),
        "timestamp": datetime.now().isoformat(),
    }


def get_weekly_summary() -> dict:
    """Return simulated weekly business summary."""
    days = []
    base_revenue = 10000
    for i in range(7):
        day = datetime.now() - timedelta(days=6 - i)
        days.append({
            "date": day.strftime("%a %d"),
            "revenue": round(base_revenue * random.uniform(0.7, 1.4), 2),
            "orders": random.randint(40, 130),
        })

    total_revenue = sum(d["revenue"] for d in days)
    total_orders = sum(d["orders"] for d in days)

    return {
        "days": days,
        "total_revenue": round(total_revenue, 2),
        "total_orders": total_orders,
        "avg_daily_revenue": round(total_revenue / 7, 2),
        "best_day": max(days, key=lambda x: x["revenue"])["date"],
        "top_product": random.choice(["Pro Plan", "Enterprise License", "API Credits", "Add-ons"]),
        "churn_rate": round(random.uniform(1.0, 4.0), 2),
        "nps_score": random.randint(42, 78),
    }


def get_active_alerts() -> list[dict]:
    """Return list of currently active business alerts."""
    possible_alerts = [
        {
            "level": "critical",
            "type": "payment_gateway",
            "message": "Payment gateway timeout rate above 10%",
            "since": "14:32",
            "affected": "~23 transactions",
        },
        {
            "level": "warning",
            "type": "inventory",
            "message": "SKU-4821 stock below reorder threshold (12 units left)",
            "since": "11:05",
            "affected": "Product page",
        },
        {
            "level": "info",
            "type": "traffic",
            "message": "Unusual traffic spike from social media referral",
            "since": "16:48",
            "affected": "+340% vs avg",
        },
    ]
    # Randomly return 0-3 active alerts for demo variety
    count = random.randint(0, len(possible_alerts))
    return random.sample(possible_alerts, count)


def get_sales_breakdown() -> dict:
    """Return simulated sales breakdown by channel."""
    return {
        "channels": {
            "organic": random.randint(30, 50),
            "paid_ads": random.randint(20, 35),
            "referral": random.randint(10, 20),
            "email": random.randint(8, 18),
            "social": random.randint(5, 15),
        },
        "top_countries": [
            ("🇺🇸 USA", random.randint(40, 55)),
            ("🇬🇧 UK", random.randint(10, 20)),
            ("🇩🇪 Germany", random.randint(5, 15)),
            ("🇨🇦 Canada", random.randint(4, 12)),
        ],
    }


def generate_sample_report_csv() -> str:
    """Generate a sample CSV report as a string."""
    lines = ["Date,Revenue,Orders,Conversion Rate,New Users"]
    for i in range(7):
        day = datetime.now() - timedelta(days=6 - i)
        lines.append(
            f"{day.strftime('%Y-%m-%d')},"
            f"{round(random.uniform(8000, 15000), 2)},"
            f"{random.randint(45, 130)},"
            f"{round(random.uniform(2.0, 8.5), 2)},"
            f"{random.randint(5, 30)}"
        )
    return "\n".join(lines)
